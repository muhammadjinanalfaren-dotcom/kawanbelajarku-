/* KawanBelajarku — modul bersama (ikon 3D glossy, tema, konfigurasi, lampiran) */
(function(){
const K=window.KB={cfg:{ui:{},style:{}},missing:false};
K.esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
K.THEMES={
  sky:{bg:'#DCE9F8',deep:'#1E56B5'},
  teal:{bg:'#D8F0EA',deep:'#167867'},
  amber:{bg:'#FBEBC8',deep:'#A36207'},
  coral:{bg:'#F9DDD7',deep:'#B33B2A'},
  violet:{bg:'#E7E1F8',deep:'#5742B8'},
  lime:{bg:'#E5F0CB',deep:'#52750E'},
  rose:{bg:'#F8DDEB',deep:'#A63279'},
  slate:{bg:'#E2E7EF',deep:'#42536B'}
};
const mix=K.mix=(c,f)=>{const n=parseInt(c.slice(1),16),t=f<0?0:255,p=Math.abs(f);return'#'+[n>>16,n>>8&255,n&255].map(v=>Math.round(v+(t-v)*p).toString(16).padStart(2,'0')).join('')};

/* ---- Ikon 3D Glossy SVG (dengan gradasi lembut, bayangan 3D, & kilau) ---- */
const DEFS = `
<defs>
  <radialGradient id="sh3" cx="50%" cy="50%" r="50%">
    <stop offset="0%" stop-color="#142B62" stop-opacity="0.22"/>
    <stop offset="70%" stop-color="#142B62" stop-opacity="0.08"/>
    <stop offset="100%" stop-color="#142B62" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="gBlue" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#5AA5FF"/>
    <stop offset="55%" stop-color="#2468E8"/>
    <stop offset="100%" stop-color="#1342A8"/>
  </linearGradient>
  <linearGradient id="gBlueLt" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" stop-color="#89C4FF"/>
    <stop offset="100%" stop-color="#3B82F6"/>
  </linearGradient>
  <linearGradient id="gGold" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#FFE47A"/>
    <stop offset="50%" stop-color="#FFB81C"/>
    <stop offset="100%" stop-color="#D97B06"/>
  </linearGradient>
  <linearGradient id="gOrange" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#FF9A5A"/>
    <stop offset="55%" stop-color="#F25C2A"/>
    <stop offset="100%" stop-color="#B83212"/>
  </linearGradient>
  <linearGradient id="gPurple" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#A78BFA"/>
    <stop offset="55%" stop-color="#6D44E5"/>
    <stop offset="100%" stop-color="#4323A6"/>
  </linearGradient>
  <linearGradient id="gTeal" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#5EEAD4"/>
    <stop offset="55%" stop-color="#14B8A6"/>
    <stop offset="100%" stop-color="#0D7A6E"/>
  </linearGradient>
  <linearGradient id="gGreen" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#86EFAC"/>
    <stop offset="55%" stop-color="#22C55E"/>
    <stop offset="100%" stop-color="#15803D"/>
  </linearGradient>
  <linearGradient id="gPaper" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" stop-color="#FFFFFF"/>
    <stop offset="100%" stop-color="#E6EEFA"/>
  </linearGradient>
  <linearGradient id="gSlate" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#94A3B8"/>
    <stop offset="60%" stop-color="#475569"/>
    <stop offset="100%" stop-color="#1E293B"/>
  </linearGradient>
</defs>`;

const SH = (y=58, rx=22) => `<ellipse cx="32" cy="${y}" rx="${rx}" ry="4.5" fill="url(#sh3)"/>`;

K.ICONS = {
  /* Folder biru 3D dengan dokumen & bintang emas (Materi Tersimpan) */
  folder(){
    return SH(57,23) +
      `<path d="M10 17c0-3.3 2.7-6 6-6h11l4.5 4.5H48c3.3 0 6 2.7 6 6v25c0 3.3-2.7 6-6 6H16c-3.3 0-6-2.7-6-6V17z" fill="#164BB8"/>` +
      `<rect x="15" y="13" width="32" height="26" rx="4" fill="url(#gPaper)" transform="rotate(-4 31 26)"/>` +
      `<path d="M20 19h16M20 24h12" stroke="#B7CCF0" stroke-width="2.4" stroke-linecap="round" transform="rotate(-4 31 26)"/>` +
      `<path d="M8 23c0-2.8 2.2-5 5-5h38c2.8 0 5 2.2 5 5l-2 24c-.3 3-2.7 5-5.7 5H15.7c-3 0-5.4-2-5.7-5L8 23z" fill="url(#gBlue)"/>` +
      `<path d="M13 19.5h38" stroke="#99CBFF" stroke-width="1.8" stroke-linecap="round" opacity="0.8"/>` +
      `<rect x="16" y="25" width="12" height="3.2" rx="1.6" fill="#FFFFFF" opacity="0.85"/>` +
      `<g transform="translate(47,43)">` +
        `<circle cx="0" cy="1.5" r="9.5" fill="#B45309" opacity="0.35"/>` +
        `<path d="M0-10l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L0 4.8l-5.8 3.1 1.1-6.5L-9.4-3.2l6.5-.9z" fill="url(#gGold)" stroke="#FFF3B0" stroke-width="0.8" stroke-linejoin="round"/>` +
      `</g>`;
  },

  /* Clipboard biru 3D dengan centang & pensil kuning (Pusat Latihan) */
  clip(){
    return SH(58,21) +
      `<g transform="rotate(-5 30 33)">` +
        `<rect x="13" y="12" width="32" height="42" rx="7" fill="#1544A6"/>` +
        `<rect x="13" y="10" width="32" height="42" rx="7" fill="url(#gBlue)"/>` +
        `<rect x="17" y="15" width="24" height="33" rx="4" fill="url(#gPaper)"/>` +
        `<rect x="22" y="7" width="14" height="7" rx="3.5" fill="url(#gSlate)"/>` +
        `<circle cx="29" cy="10.5" r="1.5" fill="#E2E8F0"/>` +
        `<rect x="20" y="21" width="5" height="5" rx="1.4" fill="#3B82F6"/>` +
        `<path d="M21.2 23.5l1.1 1.1 2-2.2" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>` +
        `<path d="M28 23.5h9" stroke="#94A3B8" stroke-width="2.4" stroke-linecap="round"/>` +
        `<rect x="20" y="29" width="5" height="5" rx="1.4" fill="#3B82F6"/>` +
        `<path d="M21.2 31.5l1.1 1.1 2-2.2" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>` +
        `<path d="M28 31.5h9" stroke="#94A3B8" stroke-width="2.4" stroke-linecap="round"/>` +
        `<rect x="20" y="37" width="5" height="5" rx="1.4" fill="#CBD5E1"/>` +
        `<path d="M28 39.5h7" stroke="#CBD5E1" stroke-width="2.4" stroke-linecap="round"/>` +
      `</g>` +
      `<g transform="translate(45,33) rotate(36)">` +
        `<rect x="-3.5" y="-15" width="7" height="24" rx="2" fill="url(#gGold)"/>` +
        `<rect x="-3.5" y="-17" width="7" height="4.5" rx="1.5" fill="#F43F5E"/>` +
        `<polygon points="-3.5,9 3.5,9 0,16" fill="#FDE68A"/>` +
        `<polygon points="-1.2,13.5 1.2,13.5 0,16" fill="#1E293B"/>` +
      `</g>`;
  },

  /* Kalender merah 3D dengan jam biru (Agenda Belajar) */
  cal(){
    return SH(58,22) +
      `<rect x="11" y="13" width="38" height="39" rx="8" fill="#CBD5E1"/>` +
      `<rect x="11" y="11" width="38" height="39" rx="8" fill="url(#gPaper)"/>` +
      `<path d="M11 19c0-4.4 3.6-8 8-8h22c4.4 0 8 3.6 8 8v5H11v-5z" fill="url(#gOrange)"/>` +
      `<rect x="19" y="7" width="4.5" height="9" rx="2.2" fill="url(#gSlate)"/>` +
      `<rect x="36.5" y="7" width="4.5" height="9" rx="2.2" fill="url(#gSlate)"/>` +
      `<g fill="#CBD5E1">` +
        `<rect x="17" y="28" width="6" height="5" rx="1.5"/>` +
        `<rect x="27" y="28" width="6" height="5" rx="1.5"/>` +
        `<rect x="37" y="28" width="6" height="5" rx="1.5"/>` +
        `<rect x="17" y="36" width="6" height="5" rx="1.5"/>` +
        `<rect x="27" y="36" width="6" height="5" rx="1.5" fill="#93C5FD"/>` +
      `</g>` +
      `<g transform="translate(46,42)">` +
        `<circle cx="0" cy="1.5" r="11" fill="#1E3A8A" opacity="0.25"/>` +
        `<circle cx="0" cy="0" r="10.5" fill="url(#gBlue)"/>` +
        `<circle cx="0" cy="0" r="7.5" fill="#FFFFFF"/>` +
        `<path d="M0-4.5V0l3.2 2" fill="none" stroke="#1D4ED8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>` +
      `</g>`;
  },

  /* Grafik batang warna-warni 3D + panah naik emas (Statistik Belajar) */
  chart(){
    return SH(58,23) +
      `<rect x="12" y="36" width="8" height="16" rx="3" fill="url(#gPurple)"/>` +
      `<rect x="22" y="30" width="8" height="22" rx="3" fill="url(#gOrange)"/>` +
      `<rect x="32" y="24" width="8" height="28" rx="3" fill="url(#gGreen)"/>` +
      `<rect x="42" y="17" width="8" height="35" rx="3" fill="url(#gBlue)"/>` +
      `<path d="M13 28 L27 21 L36 16 L47 9" fill="none" stroke="url(#gGold)" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<polygon points="51,7 42,7 48,14" fill="#F59E0B"/>`;
  },

  /* Clapperboard ungu 3D dengan tombol play (Pilihan Minggu Ini) */
  video(){
    return SH(58,22) +
      `<g transform="rotate(-5 32 34)">` +
        `<rect x="12" y="21" width="40" height="30" rx="7" fill="#3B1D8C"/>` +
        `<rect x="12" y="19" width="40" height="30" rx="7" fill="url(#gPurple)"/>` +
        `<g transform="rotate(-11 14 19)">` +
          `<rect x="12" y="12" width="40" height="7.5" rx="3" fill="#4C28B0"/>` +
          `<path d="M18 12l4 7.5M28 12l4 7.5M38 12l4 7.5" stroke="#DDD6FE" stroke-width="3"/>` +
        `</g>` +
        `<circle cx="32" cy="34" r="9.5" fill="#FFFFFF" opacity="0.22"/>` +
        `<polygon points="29,28.5 29,39.5 38.5,34" fill="#FFFFFF"/>` +
      `</g>`;
  },

  /* Mahkota emas 3D glossy dengan bintang (Pencapaian) */
  crown(){
    return SH(58,22) +
      `<path d="M12 43L9 21l13 10 10-16 10 16 13-10-3 22H12z" fill="url(#gGold)" stroke="#FDE047" stroke-width="1" stroke-linejoin="round"/>` +
      `<path d="M32 15l10 16 13-10-3 22H32V15z" fill="#D97706" opacity="0.22"/>` +
      `<rect x="12" y="42" width="40" height="7.5" rx="3.7" fill="#D97706"/>` +
      `<rect x="12" y="41" width="40" height="7" rx="3.5" fill="url(#gGold)"/>` +
      `<circle cx="9" cy="19.5" r="3.4" fill="#FBBF24"/>` +
      `<circle cx="32" cy="13.5" r="3.8" fill="#FDE047"/>` +
      `<circle cx="55" cy="19.5" r="3.4" fill="#FBBF24"/>` +
      `<path d="M32 25l2.1 4.2 4.6.7-3.3 3.2.8 4.6-4.2-2.2-4.2 2.2.8-4.6-3.3-3.2 4.6-.7z" fill="#FFFBEB"/>`;
  },

  /* Target panah 3D (Misi Harian) */
  target(){
    return SH(58,20) +
      `<circle cx="31" cy="34" r="20" fill="#B91C1C"/>` +
      `<circle cx="30" cy="33" r="20" fill="url(#gOrange)"/>` +
      `<circle cx="30" cy="33" r="14.5" fill="#FFFFFF"/>` +
      `<circle cx="30" cy="33" r="9.5" fill="url(#gOrange)"/>` +
      `<circle cx="30" cy="33" r="4.5" fill="#FFFFFF"/>` +
      `<path d="M30 33L49 14" stroke="#334155" stroke-width="3" stroke-linecap="round"/>` +
      `<polygon points="48,15 55,14 51,19" fill="#FBBF24"/>` +
      `<polygon points="48,15 49,8 44,12" fill="#F59E0B"/>`;
  },

  /* Kotak hadiah 3D (Hadiah Misi Harian) */
  gift(){
    return SH(58,20) +
      `<rect x="14" y="26" width="36" height="25" rx="5" fill="url(#gPurple)"/>` +
      `<rect x="11" y="19" width="42" height="9" rx="4" fill="#7C3AED"/>` +
      `<rect x="29" y="19" width="6" height="32" fill="url(#gGold)"/>` +
      `<rect x="14" y="34" width="36" height="5.5" fill="url(#gGold)"/>` +
      `<path d="M32 19c-4-7-12-7-12-1.5 0 3.5 7 3.5 12 1.5zm0 0c4-7 12-7 12-1.5 0 3.5-7 3.5-12 1.5z" fill="none" stroke="#FBBF24" stroke-width="3.2"/>`;
  },

  /* Buku 3D (Header & Materi) */
  book(){
    return SH(58,20) +
      `<rect x="14" y="11" width="36" height="42" rx="6" fill="#1E40AF"/>` +
      `<rect x="14" y="9" width="36" height="42" rx="6" fill="url(#gBlue)"/>` +
      `<path d="M19 9v42" stroke="#1D4ED8" stroke-width="2.5"/>` +
      `<rect x="24" y="16" width="20" height="10" rx="2.5" fill="#FFFFFF" opacity="0.92"/>` +
      `<path d="M27 20h14M27 23h9" stroke="#3B82F6" stroke-width="1.8" stroke-linecap="round"/>` +
      `<path d="M16 47h32" stroke="#93C5FD" stroke-width="2"/>`;
  },

  /* Tumpukan buku 3D */
  books(){
    return SH(58,22) +
      `<rect x="12" y="38" width="40" height="11" rx="4" fill="url(#gBlue)"/>` +
      `<rect x="15" y="39.5" width="34" height="3" rx="1.5" fill="#EFF6FF"/>` +
      `<rect x="14" y="26" width="38" height="11" rx="4" fill="url(#gTeal)"/>` +
      `<rect x="17" y="27.5" width="32" height="3" rx="1.5" fill="#F0FDFA"/>` +
      `<rect x="11" y="14" width="39" height="11" rx="4" fill="url(#gGold)"/>` +
      `<rect x="14" y="15.5" width="33" height="3" rx="1.5" fill="#FFFBEB"/>`;
  },

  /* Kalkulator 3D (Matematika) */
  calc(){
    return SH(58,20) +
      `<rect x="15" y="9" width="34" height="44" rx="7" fill="url(#gBlue)"/>` +
      `<rect x="20" y="14" width="24" height="10" rx="3" fill="#0F172A"/>` +
      `<path d="M34 19h7" stroke="#34D399" stroke-width="2.4" stroke-linecap="round"/>` +
      `<g fill="#FFFFFF" opacity="0.92">` +
        `<rect x="20" y="28" width="6" height="5" rx="1.5"/><rect x="29" y="28" width="6" height="5" rx="1.5"/><rect x="38" y="28" width="6" height="5" rx="1.5" fill="#FBBF24"/>` +
        `<rect x="20" y="36" width="6" height="5" rx="1.5"/><rect x="29" y="36" width="6" height="5" rx="1.5"/><rect x="38" y="36" width="6" height="5" rx="1.5" fill="#FBBF24"/>` +
        `<rect x="20" y="44" width="15" height="5" rx="1.5"/><rect x="38" y="44" width="6" height="5" rx="1.5" fill="#F97316"/>` +
      `</g>`;
  },

  /* Atom 3D (Fisika) */
  atom(){
    return SH(58,20) +
      `<g fill="none" stroke="url(#gPurple)" stroke-width="3">` +
        `<ellipse cx="32" cy="31" rx="23" ry="8.5"/>` +
        `<ellipse cx="32" cy="31" rx="23" ry="8.5" transform="rotate(60 32 31)"/>` +
        `<ellipse cx="32" cy="31" rx="23" ry="8.5" transform="rotate(120 32 31)"/>` +
      `</g>` +
      `<circle cx="32" cy="31" r="6.5" fill="url(#gGold)"/>` +
      `<circle cx="54" cy="31" r="3.8" fill="url(#gBlue)"/>` +
      `<circle cx="20" cy="50" r="3.8" fill="url(#gTeal)"/>` +
      `<circle cx="20" cy="12" r="3.8" fill="url(#gOrange)"/>`;
  },

  /* Labu kimia 3D (Kimia) */
  flask(){
    return SH(58,20) +
      `<path d="M26 11h12v10l12 24c1.5 3-.6 6.5-4 6.5H18c-3.4 0-5.5-3.5-4-6.5l12-24V11z" fill="#E0F2FE" stroke="#7DD3FC" stroke-width="1.5"/>` +
      `<path d="M20 35h24l5 10c1 2-.4 4.5-2.7 4.5H17.7c-2.3 0-3.7-2.5-2.7-4.5l5-10z" fill="url(#gTeal)"/>` +
      `<rect x="24" y="8" width="16" height="4.5" rx="2.2" fill="url(#gBlue)"/>` +
      `<circle cx="28" cy="42" r="2.2" fill="#fff" opacity="0.75"/>` +
      `<circle cx="36" cy="39" r="1.6" fill="#fff" opacity="0.75"/>`;
  },

  /* Daun & Pot 3D (Biologi) */
  leaf(){
    return SH(58,18) +
      `<path d="M32 35C32 21 44 13 52 15c1 9-6 20-20 20z" fill="url(#gGreen)"/>` +
      `<path d="M32 35C32 23 21 16 13 18c-1 8 5 17 19 17z" fill="#16A34A"/>` +
      `<path d="M21 36h22l-3 16H24l-3-16z" fill="url(#gOrange)"/>` +
      `<rect x="19" y="33" width="26" height="5" rx="2.5" fill="#EA580C"/>`;
  },

  /* Globe 3D (Geografi) */
  globe(){
    return SH(58,18) +
      `<circle cx="32" cy="28" r="18" fill="url(#gBlue)"/>` +
      `<path d="M22 18c4-3 10-2 11 2s-3 6-1 9-6 5-9 3-5-10-1-14z" fill="url(#gGreen)"/>` +
      `<path d="M38 28c4-2 8 2 6 7s-6 5-8 2 0-7 2-9z" fill="url(#gGreen)"/>` +
      `<path d="M24 51h16M32 46v5" stroke="url(#gSlate)" stroke-width="3.5" stroke-linecap="round"/>`;
  },

  /* Koin Emas 3D (Ekonomi) */
  coin(){
    return SH(58,20) +
      `<ellipse cx="32" cy="44" rx="17" ry="6.5" fill="#B45309"/>` +
      `<ellipse cx="32" cy="41" rx="17" ry="6.5" fill="url(#gGold)"/>` +
      `<ellipse cx="32" cy="35" rx="17" ry="6.5" fill="#B45309"/>` +
      `<ellipse cx="32" cy="32" rx="17" ry="6.5" fill="url(#gGold)"/>` +
      `<ellipse cx="32" cy="26" rx="17" ry="6.5" fill="#B45309"/>` +
      `<ellipse cx="32" cy="23" rx="17" ry="6.5" fill="#FDE047"/>`;
  },

  /* Pilar Sejarah 3D */
  landmark(){
    return SH(58,22) +
      `<polygon points="32,10 11,22 53,22" fill="url(#gOrange)"/>` +
      `<rect x="14" y="22" width="36" height="4" rx="1.5" fill="#FDBA74"/>` +
      `<rect x="17" y="26" width="5" height="20" rx="1.5" fill="url(#gPaper)"/>` +
      `<rect x="29.5" y="26" width="5" height="20" rx="1.5" fill="url(#gPaper)"/>` +
      `<rect x="42" y="26" width="5" height="20" rx="1.5" fill="url(#gPaper)"/>` +
      `<rect x="12" y="46" width="40" height="6" rx="2.5" fill="url(#gSlate)"/>`;
  },

  /* Tokoh / Sosial 3D */
  people(){
    return SH(58,22) +
      `<circle cx="42" cy="24" r="7" fill="url(#gGold)"/>` +
      `<path d="M31 46c0-6.5 5-11 11-11s11 4.5 11 11H31z" fill="url(#gOrange)"/>` +
      `<circle cx="24" cy="22" r="8" fill="#FDE68A"/>` +
      `<path d="M11 48c0-7.5 5.8-13 13-13s13 5.5 13 13H11z" fill="url(#gPurple)"/>`;
  },

  /* Komputer / Coding 3D */
  code(){
    return SH(58,21) +
      `<rect x="11" y="12" width="42" height="30" rx="6" fill="url(#gSlate)"/>` +
      `<rect x="15" y="16" width="34" height="22" rx="3" fill="#0F172A"/>` +
      `<path d="M25 23l-5 4 5 4M39 23l5 4-5 4M34 21l-4 12" fill="none" stroke="#38BDF8" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<rect x="27" y="42" width="10" height="6" fill="#64748B"/>` +
      `<rect x="20" y="48" width="24" height="4" rx="2" fill="#94A3B8"/>`;
  },

  /* Bintang Emas 3D */
  star(){
    return SH(58,19) +
      `<path d="M32 10l6.6 13.4 14.8 2.1-10.7 10.4 2.5 14.7L32 43.7l-13.2 6.9 2.5-14.7-10.7-10.4 14.8-2.1z" fill="url(#gGold)" stroke="#FEF08A" stroke-width="1.2" stroke-linejoin="round"/>`;
  }
};

K.ICONS.bookmark = K.ICONS.star;
K.sprite = () => `<svg width="0" height="0" style="position:absolute" aria-hidden="true">${DEFS}${Object.entries(K.ICONS).map(([n,f])=>`<symbol id="i-${n}" viewBox="0 0 64 64">${f()}</symbol>`).join('')}</svg>`;
K.icon = (n,s=48,c='') => `<svg class="i3 ${c}" width="${s}" height="${s}" viewBox="0 0 64 64" aria-hidden="true"><use href="#i-${K.ICONS[n]?n:'books'}"/></svg>`;

/* ---- ikon & warna otomatis per mata pelajaran ---- */
const norm=s=>String(s??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const hs=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return h};
const RULES=[[/matematika|mtk|kalkulus|statistik/,'calc','sky'],[/fisika/,'atom','violet'],[/kimia/,'flask','teal'],[/biologi|\bipa\b|sains/,'leaf','lime'],[/inggris|english/,'book','rose'],[/indonesia|sastra|bahasa|literasi/,'book','coral'],[/geografi/,'globe','teal'],[/ekonomi|akuntansi|keuangan/,'coin','amber'],[/sejarah/,'landmark','slate'],[/sosiologi|ppkn|pkn|pancasila|kewarganegaraan|sosial|\bips\b/,'people','violet'],[/informatika|\btik\b|komputer|pemrograman|coding/,'code','slate']];
K.auto=s=>{const n=norm(s?.name),k=Object.keys(K.THEMES);let icon='books',theme=k[hs(s?.id??n)%k.length];for(const[r,i,t]of RULES)if(r.test(n)){icon=i;theme=t;break}return{icon,theme}};

/* ---- konfigurasi (tabel site_config) ---- */
K.load=async db=>{try{const r=await db.from('site_config').select('key,value');K.missing=!!r.error;(r.data||[]).forEach(x=>{K.cfg[x.key]=x.value||{}})}catch(e){K.missing=true}K.applyUI()};
K.save=(db,key,value)=>db.from('site_config').upsert({key,value,updated_at:new Date().toISOString()});
K.applyUI=()=>{const u=K.cfg.ui||{},r=document.documentElement.style;
 if(/^#[0-9a-f]{6}$/i.test(u.color||'')){r.setProperty('--brand',u.color);r.setProperty('--brand-soft',mix(u.color,.88));let s=document.getElementById('kbui');if(!s){s=document.createElement('style');s.id='kbui';document.head.appendChild(s)}s.textContent='.top,.sbtn.primary{background:var(--brand)!important}.sbtn.primary{border-color:var(--brand)!important}'}
 if(u.name)document.querySelectorAll('[data-kb-name]').forEach(e=>{e.textContent=u.name});
 document.querySelectorAll('[data-kb-welcome]').forEach(e=>{e.textContent=u.welcome||''})};

/* ---- fitur & lampiran ---- */
K.featCards=l=>l.map(f=>{const t=K.THEMES[f.theme]||K.THEMES.sky;return`<a class="item fcard" href="/pelajaran.html#/fitur/${encodeURIComponent(f.id)}" style="background:${t.bg};border-color:transparent">${K.icon(f.icon,56)}<h3>${K.esc(f.title)}</h3><p>${K.esc(f.description||'')}</p></a>`}).join('');
K.yt=u=>{const m=String(u).match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([\w-]{11})/);return m?m[1]:null};
K.attView=a=>{const t=K.esc(a.title||'Lampiran'),ok=/^https?:\/\//i.test(a.url||''),u=ok?K.esc(a.url):'#';
 if(a.kind==='video'){const y=K.yt(a.url);return`<figure class="att"><div class="vid">${y?`<iframe src="https://www.youtube-nocookie.com/embed/${y}" title="${t}" allowfullscreen loading="lazy"></iframe>`:`<video src="${u}" controls preload="metadata" playsinline></video>`}</div><figcaption>${t}</figcaption></figure>`}
 return`<a class="att" href="${u}" target="_blank" rel="noopener"><b>${t}</b><small>${a.kind==='link'?'Buka tautan':'Buka / unduh file'}</small></a>`};

document.head.insertAdjacentHTML('beforeend','<style>[hidden]{display:none!important}.vid{position:relative;aspect-ratio:16/9;background:#000;border-radius:14px;overflow:hidden}.vid iframe,.vid video{position:absolute;inset:0;width:100%;height:100%;border:0}figure.att{margin:12px 0}figure.att figcaption{font-size:14px;color:#74809A;margin-top:6px}a.att{display:block;margin:10px 0;padding:14px;border:1px solid #E1E6EE;border-radius:14px;background:#fff;color:inherit;text-decoration:none}a.att small{display:block;color:#74809A}.fcard{display:block;text-decoration:none;color:inherit}.fcard .i3{margin-bottom:8px}</style>');
document.addEventListener('DOMContentLoaded',()=>document.body.insertAdjacentHTML('afterbegin',K.sprite()));
})();
